# Brion's Advent of Code helpers

This is a small collection of simple helper functions, classes, and other
stuff to help simplify frequently re-used code between challenges in the
Advent of Code.
