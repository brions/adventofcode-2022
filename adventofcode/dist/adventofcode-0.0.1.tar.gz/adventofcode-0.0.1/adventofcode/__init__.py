"""
adventofcode.

A simple collection of boilerplate code used for Advent of Code challenges
"""

__version__ = "0.1"
__author__ = 'Brion Swanson'
__all__ = ["helpers"]
